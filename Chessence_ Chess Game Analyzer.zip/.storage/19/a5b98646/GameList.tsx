import React, { useState, useMemo } from 'react';
import { ChessComGame } from '@/types/chess';
import { ChessComApi } from '@/services/chessComApi';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, Calendar, Clock, Trophy, User } from 'lucide-react';
import { format } from 'date-fns';

interface GameListProps {
  games: ChessComGame[];
  playerUsername: string;
  onSelectGame: (game: ChessComGame) => void;
  loading?: boolean;
}

export function GameList({ games, playerUsername, onSelectGame, loading }: GameListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterYear, setFilterYear] = useState<string>('all');
  const [filterResult, setFilterResult] = useState<string>('all');
  const [filterTimeClass, setFilterTimeClass] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const gamesPerPage = 20;

  const filteredGames = useMemo(() => {
    return games.filter(game => {
      const opponent = game.white.username.toLowerCase() === playerUsername.toLowerCase() 
        ? game.black.username 
        : game.white.username;
      
      const gameYear = new Date(game.end_time * 1000).getFullYear().toString();
      const result = ChessComApi.formatGameResult(game, playerUsername);
      
      const matchesSearch = searchTerm === '' || 
        opponent.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesYear = filterYear === 'all' || gameYear === filterYear;
      const matchesResult = filterResult === 'all' || result.toLowerCase().includes(filterResult.toLowerCase());
      const matchesTimeClass = filterTimeClass === 'all' || game.time_class === filterTimeClass;
      
      return matchesSearch && matchesYear && matchesResult && matchesTimeClass;
    });
  }, [games, searchTerm, filterYear, filterResult, filterTimeClass, playerUsername]);

  const years = useMemo(() => {
    const gameYears = games.map(game => new Date(game.end_time * 1000).getFullYear());
    return [...new Set(gameYears)].sort((a, b) => b - a);
  }, [games]);

  const timeClasses = useMemo(() => {
    const classes = games.map(game => game.time_class);
    return [...new Set(classes)];
  }, [games]);

  const paginatedGames = useMemo(() => {
    const startIndex = (currentPage - 1) * gamesPerPage;
    return filteredGames.slice(startIndex, startIndex + gamesPerPage);
  }, [filteredGames, currentPage]);

  const totalPages = Math.ceil(filteredGames.length / gamesPerPage);

  const getResultBadgeColor = (result: string) => {
    if (result.includes('Won')) return 'bg-green-600';
    if (result.includes('Lost') || result.includes('Resignation')) return 'bg-red-600';
    return 'bg-yellow-600';
  };

  const getPlayerColor = (game: ChessComGame) => {
    return game.white.username.toLowerCase() === playerUsername.toLowerCase() ? 'white' : 'black';
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Card key={i} className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="animate-pulse space-y-3">
                <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                <div className="h-3 bg-gray-700 rounded w-1/2"></div>
                <div className="h-3 bg-gray-700 rounded w-2/3"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="space-y-4 p-4 bg-gray-800 rounded-lg border border-gray-700">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search by opponent name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-700 border-gray-600 text-white"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Select value={filterYear} onValueChange={setFilterYear}>
            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
              <SelectValue placeholder="Filter by year" />
            </SelectTrigger>
            <SelectContent className="bg-gray-700 border-gray-600">
              <SelectItem value="all">All Years</SelectItem>
              {years.map(year => (
                <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterResult} onValueChange={setFilterResult}>
            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
              <SelectValue placeholder="Filter by result" />
            </SelectTrigger>
            <SelectContent className="bg-gray-700 border-gray-600">
              <SelectItem value="all">All Results</SelectItem>
              <SelectItem value="won">Wins</SelectItem>
              <SelectItem value="lost">Losses</SelectItem>
              <SelectItem value="draw">Draws</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterTimeClass} onValueChange={setFilterTimeClass}>
            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
              <SelectValue placeholder="Filter by time control" />
            </SelectTrigger>
            <SelectContent className="bg-gray-700 border-gray-600">
              <SelectItem value="all">All Time Controls</SelectItem>
              {timeClasses.map(tc => (
                <SelectItem key={tc} value={tc}>{tc.charAt(0).toUpperCase() + tc.slice(1)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Games List */}
      <div className="space-y-3">
        {paginatedGames.map((game, index) => {
          const opponent = game.white.username.toLowerCase() === playerUsername.toLowerCase() 
            ? game.black 
            : game.white;
          const playerColor = getPlayerColor(game);
          const result = ChessComApi.formatGameResult(game, playerUsername);
          const timeClass = ChessComApi.parseTimeControl(game.time_control);
          
          return (
            <Card key={`${game.uuid}-${index}`} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-gray-400" />
                        <span className="font-semibold text-white">{opponent.username}</span>
                        <span className="text-gray-400">({opponent.rating})</span>
                      </div>
                      <Badge 
                        className={`${getResultBadgeColor(result)} text-white`}
                      >
                        {result}
                      </Badge>
                      <Badge 
                        variant="outline" 
                        className={`border-gray-600 ${playerColor === 'white' ? 'text-white' : 'text-gray-300'}`}
                      >
                        {playerColor === 'white' ? '⚪' : '⚫'} {playerColor}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-gray-400">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {format(new Date(game.end_time * 1000), 'MMM dd, yyyy')}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {timeClass}
                      </div>
                      <div className="flex items-center gap-1">
                        <Trophy className="w-4 h-4" />
                        {game.rated ? 'Rated' : 'Casual'}
                      </div>
                    </div>
                  </div>
                  
                  <Button 
                    onClick={() => onSelectGame(game)}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Analyze Game
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center gap-2 pt-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Previous
          </Button>
          
          <span className="text-sm text-gray-400 px-4">
            Page {currentPage} of {totalPages} ({filteredGames.length} games)
          </span>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
}