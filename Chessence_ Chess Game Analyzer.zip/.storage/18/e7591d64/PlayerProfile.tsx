import React from 'react';
import { ChessComProfile } from '@/types/chess';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { User, MapPin, Calendar, Users, Crown } from 'lucide-react';
import { format } from 'date-fns';

interface PlayerProfileProps {
  profile: ChessComProfile;
}

export function PlayerProfile({ profile }: PlayerProfileProps) {
  const joinDate = new Date(profile.joined * 1000);
  const lastOnline = new Date(profile.last_online * 1000);

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <Avatar className="w-16 h-16">
            <AvatarImage src={profile.avatar} alt={profile.username} />
            <AvatarFallback className="bg-gray-700 text-white text-lg">
              {profile.username.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 space-y-3">
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-bold text-white">{profile.username}</h2>
              {profile.title && (
                <Badge className="bg-yellow-600 text-white">
                  <Crown className="w-3 h-3 mr-1" />
                  {profile.title}
                </Badge>
              )}
              {profile.verified && (
                <Badge className="bg-blue-600 text-white">Verified</Badge>
              )}
              {profile.is_streamer && (
                <Badge className="bg-purple-600 text-white">Streamer</Badge>
              )}
            </div>

            {profile.name && (
              <div className="flex items-center gap-2 text-gray-300">
                <User className="w-4 h-4" />
                <span>{profile.name}</span>
              </div>
            )}

            {profile.location && (
              <div className="flex items-center gap-2 text-gray-300">
                <MapPin className="w-4 h-4" />
                <span>{profile.location}</span>
              </div>
            )}

            <div className="flex items-center gap-2 text-gray-300">
              <Users className="w-4 h-4" />
              <span>{profile.followers.toLocaleString()} followers</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-400">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>Joined {format(joinDate, 'MMM dd, yyyy')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>Last online {format(lastOnline, 'MMM dd, yyyy')}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${
                profile.status === 'online' ? 'bg-green-500' : 
                profile.status === 'idle' ? 'bg-yellow-500' : 'bg-gray-500'
              }`} />
              <span className="text-gray-300 capitalize">{profile.status}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}