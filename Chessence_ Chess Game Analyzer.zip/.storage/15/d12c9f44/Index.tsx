import React, { useState, useEffect } from 'react';
import { ChessComGame, ChessComProfile } from '@/types/chess';
import { ChessComApi } from '@/services/chessComApi';
import { useChessAnalysis } from '@/hooks/useChessAnalysis';
import { GameList } from '@/components/GameList';
import { ChessBoard } from '@/components/ChessBoard';
import { GameAnalysis } from '@/components/GameAnalysis';
import { PlayerProfile } from '@/components/PlayerProfile';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Search, ChevronLeft, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';

export default function Index() {
  const [username, setUsername] = useState('');
  const [profile, setProfile] = useState<ChessComProfile | null>(null);
  const [games, setGames] = useState<ChessComGame[]>([]);
  const [selectedGame, setSelectedGame] = useState<ChessComGame | null>(null);
  const [loading, setLoading] = useState(false);
  const [gamesLoading, setGamesLoading] = useState(false);
  const [view, setView] = useState<'search' | 'games' | 'analysis'>('search');

  const { analysis, loading: analysisLoading, error: analysisError } = useChessAnalysis(selectedGame);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;

    setLoading(true);
    try {
      const playerProfile = await ChessComApi.getProfile(username.trim());
      setProfile(playerProfile);
      setView('games');
      
      // Load games
      setGamesLoading(true);
      const playerGames = await ChessComApi.getAllGames(username.trim());
      setGames(playerGames);
      toast.success(`Loaded ${playerGames.length} games for ${username}`);
    } catch (error) {
      toast.error(`Failed to load profile for ${username}. Please check the username and try again.`);
      console.error('Search error:', error);
    } finally {
      setLoading(false);
      setGamesLoading(false);
    }
  };

  const handleGameSelect = (game: ChessComGame) => {
    setSelectedGame(game);
    setView('analysis');
  };

  const handleBackToGames = () => {
    setSelectedGame(null);
    setView('games');
  };

  const handleBackToSearch = () => {
    setProfile(null);
    setGames([]);
    setSelectedGame(null);
    setView('search');
    setUsername('');
  };

  if (view === 'search') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-cyan-400 bg-clip-text text-transparent mb-4">
              Chessence
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Interactive Chess.com Game Analyzer with AI-powered insights and visual board analysis
            </p>
          </div>

          {/* Search Form */}
          <div className="max-w-md mx-auto">
            <Card className="bg-gray-800 border-gray-700 shadow-2xl">
              <CardHeader>
                <CardTitle className="text-white text-center">Enter Chess.com Username</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSearch} className="space-y-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <Input
                      type="text"
                      placeholder="e.g. hikaru, gothamchess"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="pl-10 bg-gray-700 border-gray-600 text-white text-lg py-3"
                      disabled={loading}
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
                    disabled={loading || !username.trim()}
                  >
                    {loading ? (
                      <>
                        <LoadingSpinner size="sm" className="mr-2" />
                        Loading Profile...
                      </>
                    ) : (
                      'Analyze Games'
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Feature Highlights */}
            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto">
                  <Search className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white">Game History</h3>
                <p className="text-gray-400 text-sm">
                  Retrieve and analyze your complete Chess.com game history with advanced filtering
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center mx-auto">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white">AI Analysis</h3>
                <p className="text-gray-400 text-sm">
                  Deep move analysis with Stockfish engine showing blunders, mistakes, and brilliant moves
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-cyan-600 rounded-full flex items-center justify-center mx-auto">
                  <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white">Visual Board</h3>
                <p className="text-gray-400 text-sm">
                  Large, responsive chessboard with move-by-move navigation and auto-replay
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'games') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                onClick={handleBackToSearch}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                New Search
              </Button>
              <h1 className="text-3xl font-bold text-white">Game History</h1>
            </div>
          </div>

          {/* Profile */}
          {profile && (
            <div className="mb-8">
              <PlayerProfile profile={profile} />
            </div>
          )}

          {/* Games List */}
          <GameList
            games={games}
            playerUsername={profile?.username || ''}
            onSelectGame={handleGameSelect}
            loading={gamesLoading}
          />
        </div>
      </div>
    );
  }

  if (view === 'analysis' && selectedGame) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                onClick={handleBackToGames}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Back to Games
              </Button>
              <h1 className="text-3xl font-bold text-white">Game Analysis</h1>
            </div>
          </div>

          {/* Game Info */}
          <Card className="bg-gray-800 border-gray-700 mb-8">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Game Details</h3>
                  <div className="space-y-1 text-sm text-gray-300">
                    <div>White: {selectedGame.white.username} ({selectedGame.white.rating})</div>
                    <div>Black: {selectedGame.black.username} ({selectedGame.black.rating})</div>
                    <div>Time Control: {ChessComApi.parseTimeControl(selectedGame.time_control)}</div>
                    <div>Result: {ChessComApi.formatGameResult(selectedGame, profile?.username || '')}</div>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Analysis Status</h3>
                  <div className="text-sm text-gray-300">
                    {analysisLoading ? (
                      <div className="flex items-center gap-2">
                        <LoadingSpinner size="sm" />
                        Analyzing game...
                      </div>
                    ) : analysisError ? (
                      <div className="text-red-400">Analysis failed: {analysisError}</div>
                    ) : analysis ? (
                      <div className="text-green-400">Analysis complete</div>
                    ) : (
                      <div className="text-gray-400">No analysis available</div>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Analysis Content */}
          {analysisLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center space-y-4">
                <LoadingSpinner size="lg" />
                <p className="text-gray-300">Analyzing game with AI engine...</p>
                <p className="text-sm text-gray-400">This may take a few moments</p>
              </div>
            </div>
          ) : analysis ? (
            <Tabs defaultValue="board" className="space-y-6">
              <TabsList className="bg-gray-800 border-gray-700">
                <TabsTrigger value="board" className="data-[state=active]:bg-gray-700">
                  Interactive Board
                </TabsTrigger>
                <TabsTrigger value="analysis" className="data-[state=active]:bg-gray-700">
                  Analysis Report
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="board" className="space-y-6">
                <ChessBoard
                  game={selectedGame}
                  analysis={analysis.moves}
                  playerUsername={profile?.username || ''}
                />
              </TabsContent>
              
              <TabsContent value="analysis" className="space-y-6">
                <GameAnalysis
                  analysis={analysis}
                  game={selectedGame}
                  playerUsername={profile?.username || ''}
                />
              </TabsContent>
            </Tabs>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-400">Unable to analyze this game</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
}