import React, { useState, useEffect, useCallback } from 'react';
import Chessboard from 'chessboardjsx';
import { Chess } from 'chess.js';
import { ChessComGame, MoveAnalysis } from '@/types/chess';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  ChevronLeft, 
  ChevronRight,
  RotateCcw,
  Download,
  Share2
} from 'lucide-react';

interface ChessBoardProps {
  game: ChessComGame;
  analysis: MoveAnalysis[];
  playerUsername: string;
}

export function ChessBoard({ game, analysis, playerUsername }: ChessBoardProps) {
  const [gamePosition, setGamePosition] = useState(new Chess().fen());
  const [currentMoveIndex, setCurrentMoveIndex] = useState(-1);
  const [isAutoPlaying, setIsAutoPlaying] = useState(false);
  const [boardOrientation, setBoardOrientation] = useState<'white' | 'black'>('white');
  const [autoPlaySpeed, setAutoPlaySpeed] = useState([1000]);
  const [gameMoves, setGameMoves] = useState<string[]>([]);

  const isPlayerWhite = game.white.username.toLowerCase() === playerUsername.toLowerCase();

  useEffect(() => {
    // Load PGN and extract moves
    const tempChess = new Chess();
    try {
      tempChess.loadPgn(game.pgn);
      const moves = tempChess.history();
      setGameMoves(moves);
      setBoardOrientation(isPlayerWhite ? 'white' : 'black');
      setCurrentMoveIndex(-1);
      setGamePosition(new Chess().fen()); // Start position
    } catch (error) {
      console.error('Error loading PGN:', error);
      setGameMoves([]);
    }
  }, [game, isPlayerWhite]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAutoPlaying && currentMoveIndex < gameMoves.length - 1) {
      interval = setInterval(() => {
        goToMove(currentMoveIndex + 1);
      }, autoPlaySpeed[0]);
    } else if (currentMoveIndex >= gameMoves.length - 1) {
      setIsAutoPlaying(false);
    }
    return () => clearInterval(interval);
  }, [isAutoPlaying, currentMoveIndex, gameMoves.length, autoPlaySpeed]);

  const goToMove = useCallback((moveIndex: number) => {
    if (moveIndex < -1 || moveIndex >= gameMoves.length) return;
    
    const tempChess = new Chess();
    
    // Play moves up to the target index
    for (let i = 0; i <= moveIndex; i++) {
      try {
        tempChess.move(gameMoves[i]);
      } catch (error) {
        console.error('Invalid move:', gameMoves[i], error);
        return;
      }
    }
    
    setGamePosition(tempChess.fen());
    setCurrentMoveIndex(moveIndex);
  }, [gameMoves]);

  const toggleAutoPlay = () => {
    setIsAutoPlaying(!isAutoPlaying);
  };

  const flipBoard = () => {
    setBoardOrientation(boardOrientation === 'white' ? 'black' : 'white');
  };

  const getMoveQualityColor = (classification: string) => {
    switch (classification) {
      case 'brilliant': return 'bg-cyan-500';
      case 'excellent': return 'bg-green-500';
      case 'good': return 'bg-green-400';
      case 'best': return 'bg-green-300';
      case 'book': return 'bg-blue-400';
      case 'inaccuracy': return 'bg-yellow-500';
      case 'mistake': return 'bg-orange-500';
      case 'blunder': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getCurrentEvaluation = () => {
    if (currentMoveIndex >= 0 && currentMoveIndex < analysis.length) {
      return analysis[currentMoveIndex].evaluation;
    }
    return 0;
  };

  const formatEvaluation = (evaluation: number) => {
    if (Math.abs(evaluation) > 900) {
      const mateIn = Math.ceil((1000 - Math.abs(evaluation)) / 2);
      return evaluation > 0 ? `+M${mateIn}` : `-M${mateIn}`;
    }
    return evaluation > 0 ? `+${(evaluation / 100).toFixed(1)}` : `${(evaluation / 100).toFixed(1)}`;
  };

  const exportGame = () => {
    const blob = new Blob([game.pgn], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chessence-game-${game.uuid}.pgn`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const shareGame = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Chessence Game Analysis',
          text: `Check out this chess game analysis on Chessence!`,
          url: window.location.href
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 h-full">
      {/* Chessboard */}
      <div className="xl:col-span-2 flex flex-col items-center space-y-4">
        <div className="w-full max-w-4xl bg-gray-800 p-6 rounded-lg shadow-2xl">
          <div className="aspect-square w-full">
            <Chessboard
              position={gamePosition}
              orientation={boardOrientation}
              width={800}
              boardStyle={{
                boxShadow: '0 20px 40px rgba(0,0,0,0.5)',
                borderRadius: '8px'
              }}
              darkSquareStyle={{
                backgroundColor: '#4a5568'
              }}
              lightSquareStyle={{
                backgroundColor: '#e2e8f0'
              }}
            />
          </div>
          
          {/* Evaluation Bar */}
          <div className="mt-4 bg-gray-700 rounded-full h-3 relative overflow-hidden">
            <div 
              className="absolute top-0 left-0 h-full bg-white transition-all duration-300"
              style={{ 
                width: `${Math.max(0, Math.min(100, 50 + (getCurrentEvaluation() / 10)))}%` 
              }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-gray-900">
              {formatEvaluation(getCurrentEvaluation())}
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-3 p-4 bg-gray-800 rounded-lg">
          <Button
            variant="outline"
            size="sm"
            onClick={() => goToMove(-1)}
            disabled={currentMoveIndex <= -1}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <SkipBack className="w-4 h-4" />
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => goToMove(currentMoveIndex - 1)}
            disabled={currentMoveIndex <= -1}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={toggleAutoPlay}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            {isAutoPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => goToMove(currentMoveIndex + 1)}
            disabled={currentMoveIndex >= gameMoves.length - 1}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => goToMove(gameMoves.length - 1)}
            disabled={currentMoveIndex >= gameMoves.length - 1}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <SkipForward className="w-4 h-4" />
          </Button>
          
          <div className="mx-4 h-6 w-px bg-gray-600" />
          
          <Button
            variant="outline"
            size="sm"
            onClick={flipBoard}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={exportGame}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <Download className="w-4 h-4" />
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={shareGame}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <Share2 className="w-4 h-4" />
          </Button>
        </div>

        {/* Auto-play Speed Control */}
        {isAutoPlaying && (
          <div className="w-full max-w-md p-4 bg-gray-800 rounded-lg">
            <label className="text-sm text-gray-300 mb-2 block">Auto-play Speed</label>
            <Slider
              value={autoPlaySpeed}
              onValueChange={setAutoPlaySpeed}
              min={200}
              max={3000}
              step={100}
              className="w-full"
            />
            <div className="text-xs text-gray-400 mt-1 text-center">
              {(autoPlaySpeed[0] / 1000).toFixed(1)}s per move
            </div>
          </div>
        )}
      </div>

      {/* Move List and Analysis */}
      <div className="space-y-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Move Analysis</CardTitle>
          </CardHeader>
          <CardContent className="max-h-96 overflow-y-auto space-y-2">
            {analysis.map((moveAnalysis, index) => (
              <div
                key={index}
                className={`p-3 rounded-lg cursor-pointer transition-colors ${
                  currentMoveIndex === index 
                    ? 'bg-blue-600' 
                    : 'bg-gray-700 hover:bg-gray-600'
                }`}
                onClick={() => goToMove(index)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-300 text-sm">
                      {Math.floor(index / 2) + 1}{index % 2 === 0 ? '.' : '...'}
                    </span>
                    <span className="text-white font-mono">
                      {moveAnalysis.move}
                    </span>
                    <Badge 
                      className={`${getMoveQualityColor(moveAnalysis.classification)} text-white text-xs`}
                    >
                      {moveAnalysis.classification}
                    </Badge>
                  </div>
                  <span className="text-gray-400 text-sm">
                    {formatEvaluation(moveAnalysis.evaluation)}
                  </span>
                </div>
                
                {moveAnalysis.bestMove !== moveAnalysis.move && (
                  <div className="mt-1 text-xs text-gray-400">
                    Best: <span className="font-mono text-green-400">{moveAnalysis.bestMove}</span>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}