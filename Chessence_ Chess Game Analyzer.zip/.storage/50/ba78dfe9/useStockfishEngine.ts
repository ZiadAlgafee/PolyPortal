import { useState, useEffect, useCallback, useRef } from 'react';
import { Chess } from 'chess.js';
import { MoveAnalysis } from '@/types/chess';

interface StockfishEngine {
  analyzePosition: (fen: string, depth?: number) => Promise<{ evaluation: number; bestMove: string; pv: string[] }>;
  analyzeGame: (pgn: string) => Promise<MoveAnalysis[]>;
  isAnalyzing: boolean;
  analysisProgress: number;
}

export function useStockfishEngine(): StockfishEngine {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const engineRef = useRef<Worker | null>(null);

  useEffect(() => {
    // Initialize Stockfish worker
    if (typeof Worker !== 'undefined') {
      try {
        // Try to load Stockfish from CDN
        engineRef.current = new Worker('https://cdn.jsdelivr.net/npm/stockfish@16.0.0/src/stockfish.js');
        
        engineRef.current.onmessage = (e) => {
          console.log('Stockfish:', e.data);
        };
        
        engineRef.current.onerror = (error) => {
          console.error('Stockfish Worker Error:', error);
          engineRef.current = null;
        };
      } catch (error) {
        console.warn('Could not load Stockfish worker, falling back to local engine');
        engineRef.current = null;
      }
    }

    return () => {
      if (engineRef.current) {
        engineRef.current.terminate();
      }
    };
  }, []);

  const analyzePosition = useCallback(async (fen: string, depth: number = 15): Promise<{ evaluation: number; bestMove: string; pv: string[] }> => {
    return new Promise((resolve) => {
      if (!engineRef.current) {
        // Fallback to improved heuristic analysis
        const result = analyzePositionHeuristic(fen);
        resolve(result);
        return;
      }

      let evaluation = 0;
      let bestMove = '';
      let pv: string[] = [];
      let analysisComplete = false;

      const messageHandler = (e: MessageEvent) => {
        const line = e.data;
        
        if (line.includes('info depth')) {
          const depthMatch = line.match(/depth (\d+)/);
          const scoreMatch = line.match(/score (cp|mate) (-?\d+)/);
          const pvMatch = line.match(/pv (.+)/);
          
          if (depthMatch && parseInt(depthMatch[1]) >= Math.min(depth, 10)) {
            if (scoreMatch) {
              if (scoreMatch[1] === 'cp') {
                evaluation = parseInt(scoreMatch[2]);
              } else if (scoreMatch[1] === 'mate') {
                const mateIn = parseInt(scoreMatch[2]);
                evaluation = mateIn > 0 ? 1000 - mateIn : -1000 - mateIn;
              }
            }
            
            if (pvMatch) {
              pv = pvMatch[1].split(' ');
              bestMove = pv[0] || '';
            }
          }
        }
        
        if (line.includes('bestmove')) {
          const bestMoveMatch = line.match(/bestmove (\S+)/);
          if (bestMoveMatch && !bestMove) {
            bestMove = bestMoveMatch[1];
          }
          
          if (!analysisComplete) {
            analysisComplete = true;
            engineRef.current?.removeEventListener('message', messageHandler);
            resolve({ evaluation, bestMove, pv });
          }
        }
      };

      engineRef.current.addEventListener('message', messageHandler);
      
      // Send commands to Stockfish
      engineRef.current.postMessage('uci');
      engineRef.current.postMessage('ucinewgame');
      engineRef.current.postMessage(`position fen ${fen}`);
      engineRef.current.postMessage(`go depth ${depth}`);
      
      // Timeout after 10 seconds
      setTimeout(() => {
        if (!analysisComplete) {
          analysisComplete = true;
          engineRef.current?.removeEventListener('message', messageHandler);
          engineRef.current?.postMessage('stop');
          resolve(analyzePositionHeuristic(fen));
        }
      }, 10000);
    });
  }, []);

  const analyzeGame = useCallback(async (pgn: string): Promise<MoveAnalysis[]> => {
    setIsAnalyzing(true);
    setAnalysisProgress(0);
    
    const analysis: MoveAnalysis[] = [];
    
    try {
      const chess = new Chess();
      chess.loadPgn(pgn);
      const moves = chess.history();
      
      chess.reset();
      let prevEval = 0;
      
      for (let i = 0; i < moves.length; i++) {
        setAnalysisProgress((i / moves.length) * 100);
        
        const currentFen = chess.fen();
        const { evaluation: currentEval, bestMove } = await analyzePosition(currentFen, 12);
        
        const move = moves[i];
        chess.move(move);
        
        const afterFen = chess.fen();
        const { evaluation: afterEval } = await analyzePosition(afterFen, 10);
        
        // Calculate move quality based on evaluation change
        const expectedEval = -currentEval; // Flip for opponent
        const actualEval = afterEval;
        const evalLoss = expectedEval - actualEval;
        
        let classification = 'good';
        
        if (move === bestMove) {
          classification = 'best';
        } else if (evalLoss <= 10) {
          classification = 'excellent';
        } else if (evalLoss <= 25) {
          classification = 'good';
        } else if (evalLoss <= 50) {
          classification = 'inaccuracy';
        } else if (evalLoss <= 100) {
          classification = 'mistake';
        } else {
          classification = 'blunder';
        }

        // Special handling for opening moves
        if (i < 6) {
          if (evalLoss <= 50) {
            classification = isBookMove(move, i) ? 'book' : 'good';
          }
        }

        analysis.push({
          move,
          evaluation: afterEval,
          bestMove,
          classification,
          depth: 12
        });
        
        prevEval = afterEval;
      }
      
    } catch (error) {
      console.error('Error analyzing game:', error);
    } finally {
      setIsAnalyzing(false);
      setAnalysisProgress(100);
    }
    
    return analysis;
  }, [analyzePosition]);

  return { analyzePosition, analyzeGame, isAnalyzing, analysisProgress };
}

// Improved heuristic analysis as fallback
function analyzePositionHeuristic(fen: string): { evaluation: number; bestMove: string; pv: string[] } {
  const chess = new Chess(fen);
  const moves = chess.moves();
  
  if (moves.length === 0) {
    return { 
      evaluation: chess.isCheckmate() ? (chess.turn() === 'w' ? -1000 : 1000) : 0, 
      bestMove: '', 
      pv: [] 
    };
  }

  let bestEval = chess.turn() === 'w' ? -Infinity : Infinity;
  let bestMove = moves[0];
  
  for (const move of moves.slice(0, Math.min(8, moves.length))) {
    chess.move(move);
    
    const materialBalance = evaluateMaterial(chess);
    const positionValue = evaluatePosition(chess);
    const mobilityValue = chess.moves().length * (chess.turn() === 'w' ? -2 : 2);
    
    let evaluation = materialBalance + positionValue + mobilityValue;
    
    // Add some randomness but much less than before
    evaluation += (Math.random() - 0.5) * 10;
    
    if (chess.turn() === 'w' ? evaluation > bestEval : evaluation < bestEval) {
      bestEval = evaluation;
      bestMove = move;
    }
    
    chess.undo();
  }

  return { evaluation: Math.round(bestEval), bestMove, pv: [bestMove] };
}

function evaluateMaterial(chess: Chess): number {
  const board = chess.board();
  let material = 0;
  
  const pieceValues = {
    'p': 100, 'n': 320, 'b': 330, 'r': 500, 'q': 900, 'k': 0
  };
  
  for (let i = 0; i < 8; i++) {
    for (let j = 0; j < 8; j++) {
      const piece = board[i][j];
      if (piece) {
        const value = pieceValues[piece.type] || 0;
        material += piece.color === 'w' ? value : -value;
      }
    }
  }
  
  return material;
}

function evaluatePosition(chess: Chess): number {
  let position = 0;
  
  // Center control
  const centerSquares = ['d4', 'd5', 'e4', 'e5'];
  for (const square of centerSquares) {
    const piece = chess.get(square as any);
    if (piece) {
      position += piece.color === 'w' ? 10 : -10;
    }
  }
  
  // King safety
  if (chess.inCheck()) {
    position += chess.turn() === 'w' ? -30 : 30;
  }
  
  // Development (knights and bishops off back rank)
  const backRank = chess.turn() === 'w' ? '1' : '8';
  const pieces = ['b', 'n'];
  
  for (const pieceType of pieces) {
    for (let file = 'a'; file <= 'h'; file = String.fromCharCode(file.charCodeAt(0) + 1)) {
      const square = file + backRank;
      const piece = chess.get(square as any);
      if (piece && piece.type === pieceType) {
        position += piece.color === 'w' ? -15 : 15;
      }
    }
  }
  
  return position;
}

function isBookMove(move: string, moveNumber: number): boolean {
  const commonOpeningMoves = [
    ['e4', 'd4', 'Nf3', 'c4', 'g3'],  // White's first moves
    ['e5', 'e6', 'c5', 'd6', 'd5', 'Nf6', 'g6'],  // Black's responses
    ['Nf3', 'Bc4', 'Bb5', 'Nc3', 'f4', 'd3'],  // White's second moves
    ['Nc6', 'Nf6', 'Be7', 'Bb4', 'f5', 'd6']  // Black's second moves
  ];
  
  if (moveNumber < commonOpeningMoves.length) {
    return commonOpeningMoves[moveNumber].includes(move);
  }
  
  return false;
}