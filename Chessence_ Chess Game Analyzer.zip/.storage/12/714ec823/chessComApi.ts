import { ChessComGame, ChessComArchive, ChessComProfile } from '@/types/chess';

const BASE_URL = 'https://api.chess.com/pub';

export class ChessComApi {
  static async getProfile(username: string): Promise<ChessComProfile> {
    const response = await fetch(`${BASE_URL}/player/${username}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch profile for ${username}`);
    }
    return response.json();
  }

  static async getArchives(username: string): Promise<ChessComArchive> {
    const response = await fetch(`${BASE_URL}/player/${username}/games/archives`);
    if (!response.ok) {
      throw new Error(`Failed to fetch archives for ${username}`);
    }
    return response.json();
  }

  static async getGamesFromArchive(archiveUrl: string): Promise<{ games: ChessComGame[] }> {
    const response = await fetch(archiveUrl);
    if (!response.ok) {
      throw new Error(`Failed to fetch games from archive: ${archiveUrl}`);
    }
    return response.json();
  }

  static async getAllGames(username: string): Promise<ChessComGame[]> {
    try {
      const archives = await this.getArchives(username);
      const allGames: ChessComGame[] = [];

      // Fetch games from all archives (limit to last 12 months for performance)
      const recentArchives = archives.archives.slice(-12);
      
      for (const archiveUrl of recentArchives) {
        try {
          const archiveData = await this.getGamesFromArchive(archiveUrl);
          allGames.push(...archiveData.games);
        } catch (error) {
          console.error(`Failed to fetch archive ${archiveUrl}:`, error);
        }
      }

      return allGames.sort((a, b) => b.end_time - a.end_time);
    } catch (error) {
      console.error('Error fetching all games:', error);
      throw error;
    }
  }

  static parseTimeControl(timeControl: string): string {
    const parts = timeControl.split('+');
    const baseTime = parseInt(parts[0]);
    const increment = parts[1] ? parseInt(parts[1]) : 0;

    if (baseTime < 180) return 'Bullet';
    if (baseTime < 600) return 'Blitz';
    if (baseTime < 1800) return 'Rapid';
    return 'Classical';
  }

  static formatGameResult(game: ChessComGame, playerUsername: string): string {
    const isWhite = game.white.username.toLowerCase() === playerUsername.toLowerCase();
    const playerResult = isWhite ? game.white.result : game.black.result;
    
    switch (playerResult) {
      case 'win': return 'Won';
      case 'checkmated': return 'Lost';
      case 'timeout': return 'Lost on Time';
      case 'resigned': return 'Lost by Resignation';
      case 'stalemate': return 'Draw by Stalemate';
      case 'repetition': return 'Draw by Repetition';
      case 'agreed': return 'Draw Agreed';
      case 'insufficient': return 'Draw - Insufficient Material';
      default: return 'Draw';
    }
  }
}