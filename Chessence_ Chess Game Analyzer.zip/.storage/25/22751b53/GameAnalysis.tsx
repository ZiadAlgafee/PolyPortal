import React from 'react';
import { GameAnalysis as GameAnalysisType, ChessComGame } from '@/types/chess';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface GameAnalysisProps {
  analysis: GameAnalysisType;
  game: ChessComGame;
  playerUsername: string;
}

export function GameAnalysis({ analysis, game, playerUsername }: GameAnalysisProps) {
  const isPlayerWhite = game.white.username.toLowerCase() === playerUsername.toLowerCase();
  const playerAccuracy = isPlayerWhite ? analysis.accuracy.white : analysis.accuracy.black;
  const opponentAccuracy = isPlayerWhite ? analysis.accuracy.black : analysis.accuracy.white;

  const moveQualityData = [
    { name: 'Brilliant', value: analysis.moves.filter(m => m.classification === 'brilliant').length, color: '#06b6d4' },
    { name: 'Excellent', value: analysis.moves.filter(m => m.classification === 'excellent').length, color: '#10b981' },
    { name: 'Good', value: analysis.moves.filter(m => m.classification === 'good').length, color: '#84cc16' },
    { name: 'Best', value: analysis.moves.filter(m => m.classification === 'best').length, color: '#22c55e' },
    { name: 'Book', value: analysis.moves.filter(m => m.classification === 'book').length, color: '#3b82f6' },
    { name: 'Inaccuracy', value: analysis.inaccuracies, color: '#eab308' },
    { name: 'Mistake', value: analysis.mistakes, color: '#f97316' },
    { name: 'Blunder', value: analysis.blunders, color: '#ef4444' },
  ].filter(item => item.value > 0);

  const evaluationData = analysis.moves.map((move, index) => ({
    move: index + 1,
    evaluation: move.evaluation / 100,
    color: move.color
  }));

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white mb-1">{playerAccuracy}%</div>
              <div className="text-sm text-gray-400">Your Accuracy</div>
              <Progress value={playerAccuracy} className="mt-2" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white mb-1">{opponentAccuracy}%</div>
              <div className="text-sm text-gray-400">Opponent Accuracy</div>
              <Progress value={opponentAccuracy} className="mt-2" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-red-400 mb-1">{analysis.blunders}</div>
              <div className="text-sm text-gray-400">Blunders</div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-400 mb-1">{analysis.mistakes}</div>
              <div className="text-sm text-gray-400">Mistakes</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Move Quality Distribution */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Move Quality Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={moveQualityData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {moveQualityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#374151', 
                    border: '1px solid #4b5563',
                    borderRadius: '8px',
                    color: '#fff'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Evaluation Graph */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Game Evaluation</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={evaluationData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#4b5563" />
                <XAxis 
                  dataKey="move" 
                  stroke="#9ca3af"
                  fontSize={12}
                />
                <YAxis 
                  stroke="#9ca3af"
                  fontSize={12}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#374151', 
                    border: '1px solid #4b5563',
                    borderRadius: '8px',
                    color: '#fff'
                  }}
                  formatter={(value: number) => [`${value > 0 ? '+' : ''}${value.toFixed(1)}`, 'Evaluation']}
                />
                <Bar 
                  dataKey="evaluation" 
                  fill="#10b981"
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Move Quality Legend */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Move Quality Legend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
            {[
              { name: 'Brilliant', color: 'bg-cyan-500', description: 'Outstanding move' },
              { name: 'Excellent', color: 'bg-green-500', description: 'Very strong move' },
              { name: 'Good', color: 'bg-green-400', description: 'Solid move' },
              { name: 'Best', color: 'bg-green-300', description: 'Engine\'s choice' },
              { name: 'Book', color: 'bg-blue-400', description: 'Theory move' },
              { name: 'Inaccuracy', color: 'bg-yellow-500', description: 'Minor error' },
              { name: 'Mistake', color: 'bg-orange-500', description: 'Notable error' },
              { name: 'Blunder', color: 'bg-red-500', description: 'Major error' }
            ].map((quality) => (
              <div key={quality.name} className="text-center">
                <Badge className={`${quality.color} text-white mb-1 w-full`}>
                  {quality.name}
                </Badge>
                <div className="text-xs text-gray-400">{quality.description}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}