import { Chess } from 'chess.js';
import { MoveAnalysis, GameAnalysis } from '@/types/chess';

export class StockfishEngine {
  private worker: Worker | null = null;
  private isReady = false;

  constructor() {
    this.initializeEngine();
  }

  private async initializeEngine() {
    try {
      // Create a simple web worker for Stockfish simulation
      const workerCode = `
        // Simulate Stockfish worker
        self.onmessage = function(e) {
          const { command, fen, depth = 10 } = e.data;
          
          if (command === 'uci') {
            setTimeout(() => {
              self.postMessage({ type: 'uciok' });
            }, 100);
          } else if (command === 'isready') {
            setTimeout(() => {
              self.postMessage({ type: 'readyok' });
            }, 50);
          } else if (command === 'position') {
            // Position set
          } else if (command === 'go') {
            // Simulate analysis
            setTimeout(() => {
              const mockEvaluation = Math.random() * 400 - 200; // -200 to +200 centipawns
              const mockBestMove = this.generateMockMove();
              
              self.postMessage({
                type: 'bestmove',
                bestmove: mockBestMove,
                evaluation: Math.round(mockEvaluation)
              });
            }, 200 + Math.random() * 300);
          }
        };
        
        this.generateMockMove = function() {
          const moves = ['e2e4', 'e7e5', 'd2d4', 'd7d5', 'g1f3', 'b8c6', 'f1c4', 'f8c5'];
          return moves[Math.floor(Math.random() * moves.length)];
        };
      `;

      const blob = new Blob([workerCode], { type: 'application/javascript' });
      this.worker = new Worker(URL.createObjectURL(blob));

      this.worker.onmessage = (e) => {
        const { type } = e.data;
        if (type === 'readyok') {
          this.isReady = true;
        }
      };

      this.sendCommand('uci');
      await this.waitForReady();
    } catch (error) {
      console.error('Failed to initialize Stockfish:', error);
    }
  }

  private sendCommand(command: string) {
    if (this.worker) {
      this.worker.postMessage({ command });
    }
  }

  private async waitForReady(): Promise<void> {
    this.sendCommand('isready');
    return new Promise((resolve) => {
      const checkReady = () => {
        if (this.isReady) {
          resolve();
        } else {
          setTimeout(checkReady, 100);
        }
      };
      checkReady();
    });
  }

  async analyzePosition(fen: string, depth: number = 10): Promise<{ bestMove: string; evaluation: number }> {
    return new Promise((resolve) => {
      if (!this.worker) {
        resolve({ bestMove: 'e2e4', evaluation: 0 });
        return;
      }

      const timeout = setTimeout(() => {
        resolve({ bestMove: 'e2e4', evaluation: 0 });
      }, 2000);

      this.worker.onmessage = (e) => {
        const { type, bestmove, evaluation } = e.data;
        if (type === 'bestmove') {
          clearTimeout(timeout);
          resolve({ bestMove: bestmove, evaluation });
        }
      };

      this.worker.postMessage({
        command: 'position',
        fen
      });

      this.worker.postMessage({
        command: 'go',
        depth
      });
    });
  }

  async analyzeGame(pgn: string): Promise<GameAnalysis> {
    const chess = new Chess();
    chess.loadPgn(pgn);
    
    const history = chess.history({ verbose: true });
    const moves: MoveAnalysis[] = [];
    let blunders = 0;
    let mistakes = 0;
    let inaccuracies = 0;

    // Reset to start position
    chess.reset();
    let previousEvaluation = 0;

    for (let i = 0; i < history.length; i++) {
      const move = history[i];
      
      // Get position before move
      const currentFen = chess.fen();
      
      // Analyze current position
      const analysis = await this.analyzePosition(currentFen, 8);
      
      // Make the actual move
      chess.move(move.san);
      
      // Calculate evaluation change
      const evaluationChange = analysis.evaluation - previousEvaluation;
      const classification = this.classifyMove(evaluationChange, chess.turn() === 'w');
      
      if (classification === 'blunder') blunders++;
      else if (classification === 'mistake') mistakes++;
      else if (classification === 'inaccuracy') inaccuracies++;

      moves.push({
        move: move.san,
        bestMove: analysis.bestMove,
        evaluation: analysis.evaluation,
        evaluationChange,
        classification,
        color: move.color
      });

      previousEvaluation = analysis.evaluation;
    }

    return {
      moves,
      accuracy: {
        white: this.calculateAccuracy(moves.filter(m => m.color === 'w')),
        black: this.calculateAccuracy(moves.filter(m => m.color === 'b'))
      },
      blunders,
      mistakes,
      inaccuracies
    };
  }

  private classifyMove(evaluationChange: number, isWhiteToMove: boolean): string {
    const change = isWhiteToMove ? -evaluationChange : evaluationChange;
    
    if (change >= 200) return 'brilliant';
    if (change >= 100) return 'excellent';
    if (change >= 50) return 'good';
    if (change >= 0) return 'best';
    if (change >= -50) return 'inaccuracy';
    if (change >= -100) return 'mistake';
    return 'blunder';
  }

  private calculateAccuracy(moves: MoveAnalysis[]): number {
    if (moves.length === 0) return 100;
    
    const totalMoves = moves.length;
    const goodMoves = moves.filter(m => 
      ['brilliant', 'excellent', 'good', 'best', 'book'].includes(m.classification)
    ).length;
    
    return Math.round((goodMoves / totalMoves) * 100);
  }

  destroy() {
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
  }
}