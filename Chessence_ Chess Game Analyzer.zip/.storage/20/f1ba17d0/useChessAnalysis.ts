import { useState, useEffect } from 'react';
import { ChessComGame, GameAnalysis } from '@/types/chess';
import { StockfishEngine } from '@/services/stockfishEngine';

export function useChessAnalysis(game: ChessComGame | null) {
  const [analysis, setAnalysis] = useState<GameAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!game) {
      setAnalysis(null);
      return;
    }

    const analyzeGame = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const engine = new StockfishEngine();
        const gameAnalysis = await engine.analyzeGame(game.pgn);
        setAnalysis(gameAnalysis);
        engine.destroy();
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to analyze game');
        console.error('Analysis error:', err);
      } finally {
        setLoading(false);
      }
    };

    analyzeGame();
  }, [game]);

  return { analysis, loading, error };
}